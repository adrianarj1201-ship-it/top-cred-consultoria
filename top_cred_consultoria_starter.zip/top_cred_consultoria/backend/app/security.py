from dataclasses import dataclass
from typing import Literal
from fastapi import HTTPException, Header

Role = Literal["admin", "consultant", "customer"]

@dataclass
class Principal:
    user_id: str
    organization_id: str
    role: Role

async def get_principal(authorization: str | None = Header(default=None)) -> Principal:
    # BLOQUEIO INTENCIONAL: implementar validação OIDC/JWT de assinatura,
    # issuer, audience, expiração e revogação antes de habilitar operações.
    raise HTTPException(status_code=501,
        detail="Autenticação não configurada. Integre provedor de identidade antes de usar a API.")

def require_role(principal: Principal, *roles: Role) -> None:
    if principal.role not in roles:
        raise HTTPException(status_code=403, detail="Acesso não permitido")
