class PartnerNotConfigured(RuntimeError):
    pass

class DemoPartnerAdapter:
    # Adaptador desativado intencionalmente: não envia nem aprova propostas.
    partner_code = "NOT_CONFIGURED"
    async def submit_proposal(self, payload: dict, idempotency_key: str) -> dict:
        raise PartnerNotConfigured("Parceiro não configurado ou homologado.")
    async def get_status(self, partner_reference: str) -> dict:
        raise PartnerNotConfigured("Consulta de status não configurada.")
