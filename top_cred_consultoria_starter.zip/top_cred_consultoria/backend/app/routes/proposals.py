from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from backend.app.security import Principal, get_principal, require_role
router = APIRouter(prefix="/proposals", tags=["proposals"])

class ProposalCreate(BaseModel):
    customer_id: str
    product_type: str = Field(min_length=2, max_length=80)
    requested_amount: float = Field(gt=0, le=100000000)
    status: str = Field(default="draft", pattern="^(draft|submitted|in_review|pending_information)$")

@router.get("")
def list_proposals(principal: Principal = Depends(get_principal)):
    require_role(principal, "admin", "consultant", "customer")
    # TODO: filtrar organização, propriedade e cliente autenticado.
    return {"items": [], "note": "Persistência ainda não conectada"}

@router.post("", status_code=201)
def create_proposal(payload: ProposalCreate, principal: Principal = Depends(get_principal)):
    require_role(principal, "admin", "consultant")
    # TODO: verificar acesso ao cliente, persistir e criar evento de auditoria.
    return {"accepted": True, "proposal": payload.model_dump(), "note": "Starter sem persistência"}
