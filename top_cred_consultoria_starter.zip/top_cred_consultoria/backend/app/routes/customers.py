from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from backend.app.security import Principal, get_principal, require_role
router = APIRouter(prefix="/customers", tags=["customers"])

class CustomerCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=160)
    email: str | None = Field(default=None, max_length=254)
    phone: str | None = Field(default=None, max_length=32)
    source: str = Field(pattern="^(consultant|self_signup)$")

@router.get("")
def list_customers(principal: Principal = Depends(get_principal)):
    require_role(principal, "admin", "consultant")
    # TODO: persistência e filtro obrigatório por organização e responsável.
    return {"items": [], "note": "Persistência ainda não conectada"}

@router.post("", status_code=201)
def create_customer(payload: CustomerCreate, principal: Principal = Depends(get_principal)):
    require_role(principal, "admin", "consultant", "customer")
    # TODO: verificar permissão para source/atribuição, persistir e auditar.
    return {"accepted": True, "customer": payload.model_dump(), "note": "Starter sem persistência"}
