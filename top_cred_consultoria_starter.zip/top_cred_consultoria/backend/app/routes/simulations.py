from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from backend.app.security import Principal, get_principal
router = APIRouter(prefix="/simulations", tags=["simulations"])

class SimulationInput(BaseModel):
    principal: float = Field(gt=0, le=100000000)
    term_months: int = Field(ge=1, le=120)
    monthly_rate_percent: float = Field(ge=0, le=100)

@router.post("/estimate")
def estimate(payload: SimulationInput, principal: Principal = Depends(get_principal)):
    rate = payload.monthly_rate_percent / 100
    n, amount = payload.term_months, payload.principal
    payment = amount / n if rate == 0 else amount * rate / (1 - (1 + rate) ** (-n))
    return {"installment_estimate": round(payment, 2),
            "total_estimate": round(payment * n, 2),
            "disclaimer": "Estimativa indicativa; não é oferta nem aprovação. Custos adicionais podem existir.",
            "rate_source": "user_supplied_demo_rate"}
