from fastapi import FastAPI
from backend.app.routes import health, customers, proposals, simulations

app = FastAPI(title="Top Cred Consultoria API", version="0.1.0",
              description="Starter técnico; não usar com dados reais antes de implementar autenticação.")
app.include_router(health.router, prefix="/api/v1")
app.include_router(customers.router, prefix="/api/v1")
app.include_router(proposals.router, prefix="/api/v1")
app.include_router(simulations.router, prefix="/api/v1")
