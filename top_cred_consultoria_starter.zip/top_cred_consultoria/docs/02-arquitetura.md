# Arquitetura

- **Flutter Android**: interface e navegação por perfil; não é autoridade de autorização.
- **API FastAPI**: validação, regras de negócio, autorização e auditoria.
- **PostgreSQL**: dados transacionais e relacionamentos.
- **Adaptadores de parceiros**: um adaptador isolado por instituição, com credenciais próprias.
- **Observabilidade**: logs sem dados sensíveis, métricas, alertas e rastreamento de erros.
- **Documentos (fase posterior)**: armazenamento privado, links temporários, verificação antimalware e retenção.

## Fluxo de proposta
Usuário autenticado → validação de permissão e base legal → gravação da proposta → adaptador homologado → validação de resposta/webhook → atualização de status e auditoria → notificação permitida.

## Integrações
Nunca compartilhar credenciais entre parceiros ou colocá-las no app. Usar gestor de segredos, timeout, retries limitados, idempotência e autenticação de webhooks. Sem credenciais e homologação, integração deve permanecer desativada. Não tratar resposta não verificada como aprovação.

Estados sugeridos: `draft`, `submitted`, `in_review`, `pending_information`, `approved`, `rejected`, `cancelled`, `completed`, `integration_error`.

Desenvolvimento, homologação e produção devem ter recursos, credenciais e dados separados.
