# Critérios de aceitação

Executar em homologação com dados sintéticos.

1. Login, logout, recuperação e revogação funcionam; mensagens não permitem enumerar contas.
2. Gestão vê dados autorizados da organização; consultor não acessa carteira alheia nem alterando IDs; cliente não acessa dados de outro cliente.
3. Autocadastro verifica contato e apresenta aviso de privacidade.
4. CRM cria/atualiza clientes, registra histórico e trata duplicidades sem exposição indevida.
5. Proposta recebe ID único, status válido e trilha de alterações.
6. Integração permanece desativada sem contrato, credenciais e homologação; falhas não perdem registros.
7. Webhooks não autenticados são rejeitados e eventos repetidos são idempotentes.
8. Simulador valida entradas e coincide com cálculos de referência; exibe premissas.
9. Metas funcionam com meta zero, produção zero, excedente e arredondamento.
10. Solicitações de privacidade são registradas e encaminhadas.
11. Auditoria não contém segredos nem dados desnecessários.
12. Backups são restauráveis; erros não expõem stack traces.
13. Campos têm rótulos, contraste e mensagens de erro acessíveis.
14. Build assinado, permissões Android justificadas e política publicada antes do lançamento.

Não liberar dados reais até aprovação dos testes críticos de autorização, privacidade, recuperação de conta, backup/restauração e integração.
