# Requisitos e escopo

## Perfis
- **Gestão (`admin`)**: visão geral autorizada da organização, equipe, metas, clientes e propostas.
- **Consultor (`consultant`)**: somente clientes atribuídos, propostas sob sua responsabilidade e indicadores próprios.
- **Cliente (`customer`)**: somente seus dados, simulações e propostas.

## Requisitos funcionais
- RF01 autenticação, recuperação segura, logout e revogação de sessão.
- RF02 autorização no servidor em toda operação.
- RF03 cadastro por consultor e autocadastro do cliente.
- RF04 tratamento de duplicidade sem revelar existência de terceiros.
- RF05 histórico de atendimentos e tarefas de retorno.
- RF06 simulador com parâmetros/taxas versionados, premissas e aviso de estimativa.
- RF07 registro manual de proposta na primeira fase.
- RF08 acompanhamento autenticado de status pelo cliente.
- RF09 arquitetura de adaptadores para parceiros autorizados.
- RF10 metas, honorários e produção conforme regras configuradas.
- RF11 trilha de auditoria para operações sensíveis.
- RF12 avisos de privacidade, preferências e consentimentos quando aplicáveis.
- RF13 relatórios administrativos com permissão e auditoria.
- RF14 notificações com preferências e política antispam definidas.

## Requisitos não funcionais
HTTPS/TLS; criptografia de backups e documentos; logs sem segredos/dados excessivos; segregação por organização e usuário; monitoramento; backups com restauração testada; acessibilidade; dependências revisadas; testes automatizados.

## Fora da primeira fase
Aprovação automática, consulta a score sem autorização e base legal, envio de propostas antes de homologação de parceiro, promessa de taxa ou aprovação garantida.
