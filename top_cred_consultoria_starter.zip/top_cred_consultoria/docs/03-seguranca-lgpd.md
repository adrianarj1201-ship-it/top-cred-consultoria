# Segurança e LGPD

Documento técnico inicial; não substitui parecer jurídico.

## Governança
- Identificar controlador, operadores e canal/encarregado de privacidade conforme aplicável.
- Mapear finalidades e bases legais por operação; não presumir consentimento como base única.
- Preparar aviso de privacidade, termos, compartilhamentos, prazos de retenção e canal para direitos dos titulares.
- Documentar transferências internacionais, se houver, e contratos com parceiros.
- Definir fluxo para acesso, correção, oposição, portabilidade quando aplicável e exclusão/bloqueio respeitando obrigações legais.

## Controles
- Provedor de identidade confiável ou autenticação revisada; MFA para gestão.
- Senhas com Argon2id ou equivalente; nunca armazenar senha em texto ou criptografia reversível.
- Rate limiting, proteção contra enumeração de contas e recuperação segura.
- RBAC + verificação de propriedade em cada requisição; testar IDOR/BOLA.
- TLS, criptografia de backups, rotação de segredos e ambientes separados.
- Auditoria restrita, sem senha, token, documento integral ou payload sensível.
- Minimização: não coletar documentos até existir armazenamento privado e política de retenção.
- Backups automáticos e testes de restauração; plano de resposta a incidentes.
- Revisão de dependências, análise estática e pentest antes de produção.

## Autocadastro e crédito
Verificar e-mail/telefone; apresentar aviso de privacidade antes da coleta; evitar mensagens que revelem se um contato existe; limitar abuso. Compartilhar com parceiros apenas dados necessários e com base legal/contrato aplicáveis. Simulações devem exibir taxa, prazo, total estimado e ressalvas; nunca prometer aprovação.
