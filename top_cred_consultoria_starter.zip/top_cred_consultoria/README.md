# Top Cred Consultoria — starter técnico v0.1

Este pacote inicia o desenvolvimento do aplicativo Android com áreas para gestão, consultores e clientes, CRM, simulações indicativas e integração planejada com parceiros autorizados.

**Não é produção pronta.** A API tem bloqueio intencional de autenticação e as rotas não persistem dados. Não inserir dados reais até completar autenticação, autorização, persistência, testes e revisão de segurança.

## Estrutura
- `docs/01-requisitos.md`: escopo funcional e não funcional.
- `docs/02-arquitetura.md`: arquitetura e estratégia de integração.
- `docs/03-seguranca-lgpd.md`: requisitos de segurança e privacidade.
- `docs/04-aceitacao.md`: critérios de homologação.
- `backend/`: API FastAPI inicial e adaptador de parceiro desativado.
- `database/001_initial_schema.sql`: esquema PostgreSQL de referência.
- `mobile/`: esqueleto Flutter.
- `docker-compose.yml`: PostgreSQL local.
- `.env.example`: variáveis de configuração sem segredos reais.

## Próximos passos
1. Revisar regras comerciais e requisitos.
2. Configurar provedor de identidade (OIDC/OAuth2), JWT validado no servidor, MFA administrativo e recuperação segura.
3. Implementar persistência com migrações, autorização por organização/usuário/recurso e auditoria.
4. Criar adaptadores de parceiros somente com contrato, documentação, credenciais e sandbox homologado.
5. Executar testes unitários, integração, E2E, segurança e restauração de backup.
6. Revisar LGPD, aviso de privacidade, bases legais, retenção e contratos com parceiros.
7. Gerar e assinar APK/AAB após testes e revisão de release.

## Rodar localmente
Backend: Python 3.11+, instale `backend/requirements.txt` e execute `uvicorn backend.app.main:app --reload` a partir da raiz. A documentação da API ficará em `/docs`. As rotas protegidas retornam 501 até configurar autenticação real.

Flutter: instale Flutter SDK; em `mobile/`, execute `flutter create . --platforms=android`, `flutter pub get` e `flutter run`.

O esquema SQL é referência e deve ser aplicado por migrações versionadas. O starter não implementa integração bancária real.
