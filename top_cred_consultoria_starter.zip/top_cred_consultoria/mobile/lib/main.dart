import 'package:flutter/material.dart';

void main() => runApp(const TopCredApp());
const navy = Color(0xFF10243A);
const gold = Color(0xFFD5AD59);

class TopCredApp extends StatelessWidget {
  const TopCredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Top Cred Consultoria',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: navy), useMaterial3: true),
    home: const PrototypeHome(),
  );
}

class PrototypeHome extends StatefulWidget {
  const PrototypeHome({super.key});
  @override
  State<PrototypeHome> createState() => _PrototypeHomeState();
}

class _PrototypeHomeState extends State<PrototypeHome> {
  String role = 'Gestão';
  int selected = 0;
  List<String> get tabs => switch (role) {
    'Gestão' => ['Início', 'Equipe e metas', 'Clientes', 'Propostas', 'Simulador'],
    'Consultor' => ['Início', 'Minha meta', 'Meus clientes', 'Minhas propostas', 'Simulador'],
    _ => ['Início', 'Simular crédito', 'Minha proposta', 'Meus dados'],
  };

  @override
  Widget build(BuildContext context) {
    final pages = tabs;
    if (selected >= pages.length) selected = 0;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy, foregroundColor: Colors.white,
        title: const Text('TOP CRED'),
        actions: [PopupMenuButton<String>(
          onSelected: (v) => setState(() { role = v; selected = 0; }),
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'Gestão', child: Text('Gestão')),
            PopupMenuItem(value: 'Consultor', child: Text('Consultor')),
            PopupMenuItem(value: 'Cliente', child: Text('Cliente')),
          ],
        )],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(18)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.account_balance, color: gold, size: 36),
            SizedBox(height: 12),
            Text('Consultoria inteligente', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('Protótipo de navegação • dados fictícios', style: TextStyle(color: Color(0xFFD5DEE8))),
          ]),
        ),
        const SizedBox(height: 16),
        Text('Perfil de demonstração: $role', style: Theme.of(context).textTheme.titleMedium),
        ...List.generate(pages.length, (i) => Card(child: ListTile(
          title: Text(pages[i]), trailing: const Icon(Icons.chevron_right),
          selected: selected == i, onTap: () => setState(() => selected = i),
        ))),
        Card(color: const Color(0xFFFFF7E5), child: const Padding(
          padding: EdgeInsets.all(14),
          child: Text('Não inserir dados reais. Esta versão não possui autenticação, API conectada nem persistência.'),
        )),
        Text('Tela selecionada: ${pages[selected]}'),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected.clamp(0, pages.length - 1),
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: pages.take(3).map((p) => NavigationDestination(icon: const Icon(Icons.dashboard_outlined), label: p)).toList(),
      ),
    );
  }
}
