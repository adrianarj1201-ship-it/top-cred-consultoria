CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE organizations (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 full_name TEXT NOT NULL,
 email TEXT, phone TEXT,
 role TEXT NOT NULL CHECK (role IN ('admin','consultant','customer')),
 identity_subject TEXT UNIQUE,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE customers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 user_id UUID REFERENCES users(id),
 assigned_consultant_id UUID REFERENCES users(id),
 full_name TEXT NOT NULL, email TEXT, phone TEXT,
 source TEXT NOT NULL CHECK (source IN ('consultant','self_signup')),
 privacy_notice_version TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX customers_org_assignee_idx ON customers(organization_id, assigned_consultant_id);
CREATE TABLE interactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 customer_id UUID NOT NULL REFERENCES customers(id),
 consultant_id UUID NOT NULL REFERENCES users(id),
 interaction_type TEXT NOT NULL, summary TEXT,
 next_action_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE simulations (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 customer_id UUID REFERENCES customers(id),
 created_by UUID NOT NULL REFERENCES users(id),
 product_type TEXT NOT NULL,
 principal NUMERIC(14,2) NOT NULL CHECK (principal > 0),
 term_months INTEGER NOT NULL CHECK (term_months BETWEEN 1 AND 120),
 monthly_rate NUMERIC(8,5) NOT NULL CHECK (monthly_rate >= 0),
 estimated_installment NUMERIC(14,2) NOT NULL,
 estimated_total NUMERIC(14,2) NOT NULL,
 assumptions JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE proposals (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 customer_id UUID NOT NULL REFERENCES customers(id),
 assigned_consultant_id UUID REFERENCES users(id),
 partner_code TEXT, partner_reference TEXT,
 product_type TEXT NOT NULL,
 requested_amount NUMERIC(14,2) NOT NULL CHECK (requested_amount > 0),
 status TEXT NOT NULL CHECK (status IN ('draft','submitted','in_review','pending_information','approved','rejected','cancelled','completed','integration_error')),
 status_source TEXT NOT NULL DEFAULT 'manual' CHECK (status_source IN ('manual','partner')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX proposals_org_assignee_idx ON proposals(organization_id, assigned_consultant_id);
CREATE INDEX proposals_customer_idx ON proposals(customer_id);
CREATE TABLE goals (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 consultant_id UUID NOT NULL REFERENCES users(id),
 period_start DATE NOT NULL, period_end DATE NOT NULL,
 target_fees NUMERIC(14,2) NOT NULL CHECK (target_fees >= 0),
 commission_rate NUMERIC(6,5) NOT NULL CHECK (commission_rate >= 0 AND commission_rate <= 1),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CHECK (period_end >= period_start)
);
CREATE TABLE audit_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id UUID NOT NULL REFERENCES organizations(id),
 actor_user_id UUID REFERENCES users(id),
 action TEXT NOT NULL, resource_type TEXT NOT NULL, resource_id UUID,
 occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX audit_events_org_time_idx ON audit_events(organization_id, occurred_at DESC);

-- Antes de produção: migrações versionadas, políticas RLS, privilégios mínimos,
-- testes de autorização e política de retenção são obrigatórios.
